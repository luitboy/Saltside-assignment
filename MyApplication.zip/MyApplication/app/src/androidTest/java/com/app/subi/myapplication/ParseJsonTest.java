package com.app.subi.myapplication;

import android.test.InstrumentationTestCase;

import com.app.subi.myapplication.model.Item;
import com.app.subi.myapplication.util.ParseJson;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.List;

public class ParseJsonTest extends InstrumentationTestCase {

    private JSONArray arrayObj;
    private int jsonArraySize;

    public void testParseJson() {
        givenJSONString();
        whenStartParse();
        thenVerifyResult();
    }

    private void thenVerifyResult() {
        assertEquals("Parsing json is failed!", 2, jsonArraySize);
    }

    private void whenStartParse() {
        if (arrayObj == null) {
            return;
        }

        ParseJson pj = new ParseJson(arrayObj);
        pj.parseJson();
        List<Item> itemList = pj.getItemList();
        jsonArraySize = itemList.size();
    }

    private void givenJSONString() {
        String jsonString = "[{\"image\": \"http://dummyimage.com/715x350/105B19/907ECC\", \"description\": \"sterilizer span ticks continuity hubs procurement vision eggs backups cries gap iron conferences torpedo government catchers restaurant destroyers attribute counsel echo overcurrent classes trip environments forecastle giants conspiracies suppression things rope plans bow blots rescuers incline\", \"title\": \"terminations map autos sons utilizations\"}, " +
                "{\"image\": \"http://dummyimage.com/609x750/0D2637/BCE8DA\", \"description\": \"alarm hull wishes flesh surrender others street cliffs chain milestone audit agreement deployment\", \"title\": \"zone initial\"}]";

        try {
            arrayObj = new JSONArray(jsonString);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}