package com.app.subi.myapplication.util;

/**
 * Created by Subi on 19/2/17.
 */
public class Constants {
    public static final String ARG_TITLE = "title";
    public static final String ARG_DESC = "description";
    public static final String ARG_IMAGE = "image";
}
