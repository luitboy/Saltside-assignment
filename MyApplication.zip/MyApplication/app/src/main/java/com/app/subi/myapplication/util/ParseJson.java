package com.app.subi.myapplication.util;

import com.app.subi.myapplication.model.Item;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Subi on 18/2/17.
 */
public class ParseJson {

    private List<Item> itemList;

    public static final String JSON_ARRAY = "result";
    public static final String KEY_TITLE = "title";
    public static final String KEY_DESCRIPTION = "description";
    public static final String KEY_IMAGE = "image";

    private JSONArray json;

    public ParseJson(JSONArray json){
        this.json = json;
        itemList = new ArrayList<>();
    }

    public void parseJson(){
        try {
            for(int i=0; i<json.length(); i++){
                JSONObject jsonObj = (JSONObject) json.get(i);

                Item newItem = new Item();
                newItem.setTitle(jsonObj.getString(KEY_TITLE));
                newItem.setDescription(jsonObj.getString(KEY_DESCRIPTION));
                newItem.setImageURL(jsonObj.getString(KEY_IMAGE));

                itemList.add(newItem);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public List<Item> getItemList() {
        return itemList;
    }
}
