package com.app.subi.myapplication.ui;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.app.subi.myapplication.R;
import com.app.subi.myapplication.model.Item;
import com.app.subi.myapplication.util.Constants;
import com.app.subi.myapplication.util.ParseJson;

import org.json.JSONArray;

import java.util.List;

public class MainActivity extends ActionBarActivity {

    private final String JSON_URL = "https://gist.githubusercontent.com/maclir/f715d78b49c3b4b3b77f/raw/8854ab2fe4cbe2a5919cea97d71b714ae5a4838d/items.json";
    private final String TAG = "network request";

    private RecyclerView mRecyclerView;
    private ProgressDialog mDialog;
    private List<Item> itemList;

    private RequestQueue mRequestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.mainToolbar);
        setSupportActionBar(myToolbar);

        mRecyclerView = (RecyclerView) findViewById(R.id.listView);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.addItemDecoration(new ItemDividerDecoration(this)); //to have a divider in list item

        mRecyclerView.addOnItemTouchListener( //handler to handle onclick for recycler view
                new RecyclerItemTouchListener(getApplicationContext(), mRecyclerView, new ClickListener() {
                    @Override
                    public void onClick(View view, int position) {
                        showDetails(position);
                    }

                    @Override
                    public void onLongClick(View view, int position) {
                    }
                }));

        getJsonData();
    }

    private void showDetails(int position) {
        Intent intent = new Intent(MainActivity.this, DetailActivity.class);
        intent.putExtra(Constants.ARG_TITLE, itemList.get(position).getTitle());
        intent.putExtra(Constants.ARG_DESC, itemList.get(position).getDescription());
        intent.putExtra(Constants.ARG_IMAGE, itemList.get(position).getImageURL());
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mRequestQueue.cancelAll(TAG);
    }

    private void getJsonData() {

        showProgress();
        //using volley to download the json file
        JsonArrayRequest jsonRequest = new JsonArrayRequest(JSON_URL, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        showJSONAsList(response); //display the json items as list
                        cancelProgress();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        cancelProgress();
                        Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });

        jsonRequest.setRetryPolicy(new DefaultRetryPolicy(10000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        jsonRequest.setTag(TAG);

        mRequestQueue = Volley.newRequestQueue(this);
        mRequestQueue.add(jsonRequest);

    }

    private void showProgress() {
        mDialog = new ProgressDialog(this);
        mDialog.setMessage("Please wait...");
        mDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mDialog.setCancelable(false);
        mDialog.show();
    }

    private void cancelProgress() {
        if (mDialog != null) {
            mDialog.cancel();
        }
    }

    private void showJSONAsList(JSONArray json){
        ParseJson parser = new ParseJson(json);
        parser.parseJson();
        itemList = parser.getItemList();
        ListItemAdapter adapter = new ListItemAdapter(itemList);
        mRecyclerView.setAdapter(adapter);
    }

    public interface ClickListener { //to handle on click for item at recycler view
        void onClick(View view, int position);
        void onLongClick(View view, int position);
    }
}
