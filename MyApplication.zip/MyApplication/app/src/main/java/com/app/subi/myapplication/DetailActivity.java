package com.app.subi.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.subi.myapplication.util.Constants;
import com.app.subi.myapplication.util.PicassoTrustedClient;
import com.squareup.picasso.Picasso;

public class DetailActivity extends ActionBarActivity {

    private ImageView mImageView;
    private String mImageURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.detailToolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        Intent intent = getIntent();
        String title = intent.getStringExtra(Constants.ARG_TITLE);
        String description = intent.getStringExtra(Constants.ARG_DESC);
        mImageURL = intent.getStringExtra(Constants.ARG_IMAGE);

        mImageView = (ImageView) findViewById(R.id.detailImage);
        TextView descriptionView = (TextView) findViewById(R.id.detailDescription);
        descriptionView.setText(description);

        TextView titleView = (TextView) findViewById(R.id.detailTitle);
        titleView.setText(title);

        setData();
    }

    private void setData() {
        Picasso.with(this)
                .setLoggingEnabled(true);

        int valueInPixels = (int) getResources().getDimensionPixelSize(R.dimen.detail_page_image);

        PicassoTrustedClient.getInstance(this)
                .load(mImageURL)
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.error)
                .resize(valueInPixels, valueInPixels)
                .into(mImageView);  //downloading the image using Picasso

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        PicassoTrustedClient.getInstance(this).cancelRequest(mImageView);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { //handling back key press
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
