package com.app.subi.myapplication.ui;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;
import android.widget.TextView;

import com.app.subi.myapplication.R;
import com.app.subi.myapplication.model.Item;

import java.util.List;

/**
 * Created by Subi on 18/2/17.
 */
public class ListItemAdapter extends RecyclerView.Adapter<ListItemAdapter.ListViewHolder> {

    private String[] titles;
    private String[] descriptions;
    private Activity context;

    private List<Item> itemList;

    public ListItemAdapter(List<Item> itemList) {
        this.itemList = itemList;
    }

    @Override
    public ListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recycle_item_layout, parent, false);

        return new ListViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ListViewHolder holder, int position) {
        Item item = itemList.get(position);
        holder.title.setText(item.getTitle());
        holder.description.setText(item.getDescription());
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    protected class ListViewHolder extends RecyclerView.ViewHolder {
        public TextView title, description;

        public ListViewHolder(View view) {
            super(view);
            title = (TextView) view.findViewById(R.id.textTitle);
            description = (TextView) view.findViewById(R.id.textDescription);
        }
    }
}
